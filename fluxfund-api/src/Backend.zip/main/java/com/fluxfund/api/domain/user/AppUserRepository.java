package com.fluxfund.api.domain.user;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface AppUserRepository extends JpaRepository<AppUser, UUID> {

    Optional<AppUser> findByEmailIgnoreCaseAndActiveTrue(String email);

    Optional<AppUser> findByIdAndActiveTrue(UUID id);
}