package com.fluxfund.api.domain.audit;

public enum AuditEntityType {
    FINANCIAL_TRANSACTION,
    TRANSACTION_ALLOCATION,
    ATTACHMENT,
    SUPPORT_AGREEMENT,
    ORGANIZATION_SETTINGS,
    OFX_IMPORT
}