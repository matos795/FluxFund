package com.fluxfund.api.domain.financialtransaction.mapper;

import com.fluxfund.api.domain.account.Account;
import com.fluxfund.api.domain.account.mapper.AccountMapper;
import com.fluxfund.api.domain.category.Category;
import com.fluxfund.api.domain.category.mapper.CategoryMapper;
import com.fluxfund.api.domain.financialtransaction.FinancialTransaction;
import com.fluxfund.api.domain.financialtransaction.FinancialTransactionSource;
import com.fluxfund.api.domain.financialtransaction.FinancialTransactionType;
import com.fluxfund.api.domain.financialtransaction.FiscalDocumentPolicy;
import com.fluxfund.api.domain.financialtransaction.dto.CreateFinancialTransactionRequest;
import com.fluxfund.api.domain.financialtransaction.dto.FinancialTransactionResponse;
import com.fluxfund.api.domain.financialtransaction.dto.UpdateFinancialTransactionRequest;
import com.fluxfund.api.domain.organization.Organization;
import com.fluxfund.api.domain.transactionallocation.mapper.TransactionAllocationMapper;

public class FinancialTransactionMapper {

    private FinancialTransactionMapper() {
    }

    public static FinancialTransaction createEntity(CreateFinancialTransactionRequest request,
            Organization organization, Account account, Category category) {
        return FinancialTransaction.builder()
                .organization(organization)
                .account(account)
                .type(request.type())
                .source(FinancialTransactionSource.MANUAL)
                .category(category)
                .dueDate(request.dueDate())
                .settlementDate(request.settlementDate())
                .expectedAmount(request.expectedAmount())
                .settledAmount(request.settledAmount())
                .description(request.description())
                .documentNumber(request.documentNumber())
                .fiscalDocumentPolicy(
                        request.fiscalDocumentPolicy() != null
                                ? request.fiscalDocumentPolicy()
                                : FiscalDocumentPolicy.CATEGORY)
                .fiscalDocumentNote(normalizeText(request.fiscalDocumentNote()))
                .build();
    }

    public static FinancialTransactionResponse toResponse(FinancialTransaction financialTransaction) {
        return toResponse(financialTransaction, 0, 0, 0);
    }

    public static FinancialTransactionResponse toResponse(
            FinancialTransaction financialTransaction,
            long attachmentCount,
            long paymentProofAttachmentCount,
            long fiscalAttachmentCount) {
        return new FinancialTransactionResponse(
                financialTransaction.getId(),
                AccountMapper.toSummaryResponse(financialTransaction.getAccount()),
                financialTransaction.getCategory() != null
                        ? CategoryMapper.toSummary(financialTransaction.getCategory())
                        : null,
                financialTransaction.getType(),
                financialTransaction.getSource(),
                financialTransaction.getStatus(),
                financialTransaction.getExternalId(),
                financialTransaction.getCreditCardStatement() != null
                        ? financialTransaction.getCreditCardStatement().getId()
                        : null,
                financialTransaction.getInstallmentNumber(),
                financialTransaction.getInstallmentCount(),
                financialTransaction.getDueDate(),
                financialTransaction.getSettlementDate(),
                financialTransaction.getExpectedAmount(),
                financialTransaction.getSettledAmount(),
                financialTransaction.getInterestAmount(),
                financialTransaction.getDiscountAmount(),
                financialTransaction.getDescription(),
                financialTransaction.getRawDescription(),
                financialTransaction.getDocumentNumber(),
                financialTransaction.getFiscalDocumentPolicy(),
                financialTransaction.getFiscalDocumentNote(),
                financialTransaction.getAllocations().stream()
                        .map(TransactionAllocationMapper::toResponse).toList(),
                financialTransaction.getImportedAt(),
                financialTransaction.getClassifiedAt(),
                financialTransaction.getCreatedAt(),
                financialTransaction.getUpdatedAt(),
                attachmentCount,
                paymentProofAttachmentCount,
                fiscalAttachmentCount,
                financialTransaction.getTransferDirection(),
                financialTransaction.getTransferGroupId(),
                financialTransaction.getTransferCounterpartyAccount() != null
                        ? AccountMapper.toSummaryResponse(financialTransaction.getTransferCounterpartyAccount())
                        : null);
    }

    public static void updateEntity(
            FinancialTransaction financialTransaction,
            UpdateFinancialTransactionRequest request,
            FinancialTransactionType type,
            Category category) {

        financialTransaction.setType(type);
        financialTransaction.setCategory(category);

        financialTransaction.setDueDate(request.dueDate());
        financialTransaction.setSettlementDate(request.settlementDate());

        if (request.expectedAmount() != null) {
            financialTransaction.setExpectedAmount(request.expectedAmount());
        }

        financialTransaction.setSettledAmount(request.settledAmount());

        if (request.description() != null) {
            financialTransaction.setDescription(request.description());
        }

        financialTransaction.setDocumentNumber(request.documentNumber());

        if (request.fiscalDocumentPolicy() != null) {
            financialTransaction.setFiscalDocumentPolicy(request.fiscalDocumentPolicy());
        }

        if (request.fiscalDocumentNote() != null) {
            financialTransaction.setFiscalDocumentNote(normalizeText(request.fiscalDocumentNote()));
        }
    }

    private static String normalizeText(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        return value.trim();
    }
}
