package com.fluxfund.api.domain.creditcardstatement.controller;

import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fluxfund.api.domain.creditcardstatement.CreditCardStatement;
import com.fluxfund.api.domain.creditcardstatement.CreditCardStatementStatus;
import com.fluxfund.api.domain.creditcardstatement.dto.CreateCreditCardItemRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.CreateCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.PayCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.UpdateCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.service.CreditCardStatementService;
import com.fluxfund.api.domain.financialtransaction.FinancialTransaction;
import com.fluxfund.api.domain.financialtransaction.dto.FinancialTransactionResponse;
import com.fluxfund.api.domain.financialtransaction.mapper.FinancialTransactionMapper;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import static com.fluxfund.api.security.TenantHeaders.ORGANIZATION_ID;

@RestController
@RequestMapping("/api/v1/credit-card-statements")
@RequiredArgsConstructor
public class CreditCardStatementController {

    private final CreditCardStatementService service;

    @PostMapping
    public ResponseEntity<CreditCardStatement> create(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @RequestBody @Valid CreateCreditCardStatementRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(service.create(organizationId, request));
    }

    @GetMapping
    public ResponseEntity<Page<CreditCardStatement>> findAll(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @RequestParam(required = false) UUID creditCardAccountId,
            @RequestParam(required = false) CreditCardStatementStatus status,
            Pageable pageable) {

        return ResponseEntity.ok(
                service.findAll(organizationId, creditCardAccountId, status, pageable));
    }

    @GetMapping("/{id}")
    public ResponseEntity<CreditCardStatement> findById(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @PathVariable UUID id) {

        return ResponseEntity.ok(service.findById(organizationId, id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CreditCardStatement> update(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @PathVariable UUID id,
            @RequestBody @Valid UpdateCreditCardStatementRequest request) {

        return ResponseEntity.ok(service.update(organizationId, id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> cancel(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @PathVariable UUID id) {

        service.cancel(organizationId, id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/items")
    public ResponseEntity<FinancialTransactionResponse> addItem(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @PathVariable UUID id,
            @RequestBody @Valid CreateCreditCardItemRequest request) {

        FinancialTransaction transaction = service.addItem(organizationId, id, request);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(FinancialTransactionMapper.toResponse(transaction));
    }

    @PostMapping("/{id}/pay")
    public ResponseEntity<CreditCardStatement> pay(
            @RequestHeader(ORGANIZATION_ID) UUID organizationId,
            @PathVariable UUID id,
            @RequestBody @Valid PayCreditCardStatementRequest request) {

        return ResponseEntity.ok(service.pay(organizationId, id, request));
    }
}