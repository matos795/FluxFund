package com.fluxfund.api.domain.creditcardstatement.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fluxfund.api.domain.account.Account;
import com.fluxfund.api.domain.account.AccountType;
import com.fluxfund.api.domain.account.repository.AccountRepository;
import com.fluxfund.api.domain.category.Category;
import com.fluxfund.api.domain.category.repository.CategoryRepository;
import com.fluxfund.api.domain.creditcardstatement.CreditCardStatement;
import com.fluxfund.api.domain.creditcardstatement.CreditCardStatementStatus;
import com.fluxfund.api.domain.creditcardstatement.dto.CreateCreditCardItemRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.CreateCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.PayCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.dto.UpdateCreditCardStatementRequest;
import com.fluxfund.api.domain.creditcardstatement.repository.CreditCardStatementRepository;
import com.fluxfund.api.domain.financialtransaction.FinancialTransaction;
import com.fluxfund.api.domain.financialtransaction.FinancialTransactionSource;
import com.fluxfund.api.domain.financialtransaction.FinancialTransactionStatus;
import com.fluxfund.api.domain.financialtransaction.FinancialTransactionType;
import com.fluxfund.api.domain.financialtransaction.repository.FinancialTransactionRepository;
import com.fluxfund.api.domain.financialtransaction.service.FinancialTransactionService;
import com.fluxfund.api.domain.organization.Organization;
import com.fluxfund.api.domain.organization.OrganizationRepository;
import com.fluxfund.api.security.OrganizationAccessService;
import com.fluxfund.api.shared.exception.BusinessException;
import com.fluxfund.api.shared.exception.ResourceNotFoundException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class CreditCardStatementService {

    private final CreditCardStatementRepository statementRepository;
    private final FinancialTransactionRepository financialTransactionRepository;
    private final FinancialTransactionService financialTransactionService;
    private final OrganizationRepository organizationRepository;
    private final AccountRepository accountRepository;
    private final CategoryRepository categoryRepository;
    private final OrganizationAccessService organizationAccessService;

    public CreditCardStatement create(
            UUID organizationId,
            CreateCreditCardStatementRequest request) {

        organizationAccessService.requireFinanceWriteAccess(organizationId);

        Organization organization = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        Account creditCardAccount = accountRepository
                .findByIdAndOrganizationIdAndActiveTrue(request.creditCardAccountId(), organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Credit card account not found"));

        validateCreditCardAccount(creditCardAccount);

        CreditCardStatement statement = new CreditCardStatement();
        statement.setOrganization(organization);
        statement.setCreditCardAccount(creditCardAccount);
        statement.setName(request.name());
        statement.setClosingDate(request.closingDate());
        statement.setDueDate(request.dueDate());
        statement.setStatus(CreditCardStatementStatus.OPEN);

        return statementRepository.save(statement);
    }

    public Page<CreditCardStatement> findAll(
            UUID organizationId,
            UUID creditCardAccountId,
            CreditCardStatementStatus status,
            Pageable pageable) {

        organizationAccessService.requireReadAccess(organizationId);

        if (creditCardAccountId != null && status != null) {
            return statementRepository.findAllByOrganizationIdAndCreditCardAccountIdAndStatus(
                    organizationId,
                    creditCardAccountId,
                    status,
                    pageable);
        }

        if (creditCardAccountId != null) {
            return statementRepository.findAllByOrganizationIdAndCreditCardAccountId(
                    organizationId,
                    creditCardAccountId,
                    pageable);
        }

        if (status != null) {
            return statementRepository.findAllByOrganizationIdAndStatus(
                    organizationId,
                    status,
                    pageable);
        }

        return statementRepository.findAllByOrganizationId(organizationId, pageable);
    }

    public CreditCardStatement findById(UUID organizationId, UUID id) {
        organizationAccessService.requireReadAccess(organizationId);
        return findStatement(organizationId, id);
    }

    public CreditCardStatement update(
            UUID organizationId,
            UUID id,
            UpdateCreditCardStatementRequest request) {

        organizationAccessService.requireFinanceWriteAccess(organizationId);

        CreditCardStatement statement = findStatement(organizationId, id);

        if (statement.getStatus() == CreditCardStatementStatus.PAID) {
            throw new BusinessException("Paid credit card statements cannot be edited");
        }

        if (request.name() != null) {
            statement.setName(request.name());
        }

        if (request.closingDate() != null) {
            statement.setClosingDate(request.closingDate());
        }

        if (request.dueDate() != null) {
            statement.setDueDate(request.dueDate());
        }

        return statementRepository.save(statement);
    }

    public FinancialTransaction addItem(
            UUID organizationId,
            UUID statementId,
            CreateCreditCardItemRequest request) {

        organizationAccessService.requireFinanceWriteAccess(organizationId);

        CreditCardStatement statement = findStatement(organizationId, statementId);

        if (statement.getStatus() == CreditCardStatementStatus.PAID
                || statement.getStatus() == CreditCardStatementStatus.CANCELED) {
            throw new BusinessException("Cannot add items to paid or canceled statements");
        }

        Category category = null;

        if (request.categoryId() != null) {
            category = categoryRepository
                    .findByIdAndOrganizationIdAndActiveTrue(request.categoryId(), organizationId)
                    .orElseThrow(() -> new ResourceNotFoundException("Category not found"));

            if (!category.getType().name().equals(FinancialTransactionType.EXPENSE.name())) {
                throw new BusinessException("Credit card item category must be an expense category");
            }
        }

        FinancialTransaction transaction = FinancialTransaction.builder()
                .organization(statement.getOrganization())
                .account(statement.getPaymentAccount() != null
                        ? statement.getPaymentAccount()
                        : statement.getCreditCardAccount())
                .creditCardStatement(statement)
                .type(FinancialTransactionType.EXPENSE)
                .source(FinancialTransactionSource.CREDIT_CARD)
                .status(FinancialTransactionStatus.SETTLED)
                .category(category)
                .dueDate(request.purchaseDate())
                .settlementDate(statement.getPaymentDate() != null
                        ? statement.getPaymentDate()
                        : statement.getDueDate())
                .expectedAmount(request.amount())
                .settledAmount(request.amount())
                .interestAmount(BigDecimal.ZERO)
                .discountAmount(BigDecimal.ZERO)
                .description(request.description())
                .rawDescription(request.description())
                .documentNumber(request.documentNumber())
                .installmentNumber(request.installmentNumber())
                .installmentCount(request.installmentCount())
                .build();

        financialTransactionRepository.save(transaction);

        if (request.allocations() != null && !request.allocations().isEmpty()) {
            for (var allocation : request.allocations()) {
                financialTransactionService.addAllocation(
                        organizationId,
                        transaction.getId(),
                        allocation);
            }
        }

        return transaction;
    }

    public CreditCardStatement pay(
            UUID organizationId,
            UUID statementId,
            PayCreditCardStatementRequest request) {

        organizationAccessService.requireFinanceWriteAccess(organizationId);

        CreditCardStatement statement = findStatement(organizationId, statementId);

        if (statement.getStatus() == CreditCardStatementStatus.PAID) {
            throw new BusinessException("Credit card statement is already paid");
        }

        Account paymentAccount = accountRepository
                .findByIdAndOrganizationIdAndActiveTrue(request.paymentAccountId(), organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment account not found"));

        if (paymentAccount.getType() == AccountType.CREDIT_CARD) {
            throw new BusinessException("Payment account cannot be a credit card");
        }

        statement.setPaymentAccount(paymentAccount);
        statement.setPaymentDate(request.paymentDate());
        statement.setStatus(CreditCardStatementStatus.PAID);

        if (request.paymentTransactionId() != null) {
            FinancialTransaction paymentTransaction = financialTransactionRepository
                    .findByIdAndOrganizationId(request.paymentTransactionId(), organizationId)
                    .orElseThrow(() -> new ResourceNotFoundException("Payment transaction not found"));

            paymentTransaction.setType(FinancialTransactionType.TRANSFER);
            paymentTransaction.setCategory(null);
            paymentTransaction.setDescription("Pagamento da fatura " + statement.getName());
            paymentTransaction.setDocumentNumber(null);

            statement.setPaymentTransaction(paymentTransaction);
        }

        List<FinancialTransaction> items = financialTransactionRepository
                .findAllByCreditCardStatementIdAndOrganizationId(statementId, organizationId);

        for (FinancialTransaction item : items) {
            item.setAccount(paymentAccount);
            item.setSettlementDate(request.paymentDate());
            item.setStatus(FinancialTransactionStatus.SETTLED);

            if (item.getSettledAmount() == null) {
                item.setSettledAmount(item.getExpectedAmount());
            }
        }

        financialTransactionRepository.saveAll(items);

        return statementRepository.save(statement);
    }

    public void cancel(UUID organizationId, UUID id) {
        organizationAccessService.requireFinanceWriteAccess(organizationId);

        CreditCardStatement statement = findStatement(organizationId, id);

        if (statement.getStatus() == CreditCardStatementStatus.PAID) {
            throw new BusinessException("Paid credit card statements cannot be canceled");
        }

        statement.setStatus(CreditCardStatementStatus.CANCELED);

        List<FinancialTransaction> items = financialTransactionRepository
                .findAllByCreditCardStatementIdAndOrganizationId(id, organizationId);

        for (FinancialTransaction item : items) {
            item.setStatus(FinancialTransactionStatus.CANCELED);
        }

        financialTransactionRepository.saveAll(items);
        statementRepository.save(statement);
    }

    private CreditCardStatement findStatement(UUID organizationId, UUID id) {
        return statementRepository.findByIdAndOrganizationId(id, organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Credit card statement not found"));
    }

    private void validateCreditCardAccount(Account account) {
        if (account.getType() != AccountType.CREDIT_CARD) {
            throw new BusinessException("Account must be a credit card account");
        }
    }
}