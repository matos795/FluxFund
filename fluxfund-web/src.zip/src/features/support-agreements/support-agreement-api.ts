import { httpClient } from "@/api/http-client"
import type { PageResponse } from "@/types/page-response"
import type {
  CreateSupportAgreementRequest,
  CreateSupportAgreementVersionRequest,
  SupportAgreement,
  SupportAgreementStatus,
  UpdateSupportAgreementRequest,
} from "./support-agreement-types"

export type GetSupportAgreementsParams = {
  page?: number
  size?: number
  status?: SupportAgreementStatus
}

export type GetSupportAgreementSuggestionsParams = {
  beneficiaryId: string
  referenceDate?: string
}

export async function getSupportAgreements({
  page = 0,
  size = 10,
  status,
}: GetSupportAgreementsParams) {
  const params: Record<string, string | number | boolean> = {
    page,
    size,
  }

  if (status) {
    params.status = status
  }

  const response = await httpClient.get<PageResponse<SupportAgreement>>(
    "/api/v1/support-agreements",
    { params },
  )

  return response.data
}

export async function createSupportAgreement(
  data: CreateSupportAgreementRequest,
) {
  const response = await httpClient.post<SupportAgreement>(
    "/api/v1/support-agreements",
    data,
  )

  return response.data
}

export async function updateSupportAgreement({
  id,
  data,
}: {
  id: string
  data: UpdateSupportAgreementRequest
}) {
  const response = await httpClient.put<SupportAgreement>(
    `/api/v1/support-agreements/${id}`,
    data,
  )

  return response.data
}

export async function deleteSupportAgreement(id: string) {
  await httpClient.delete(`/api/v1/support-agreements/${id}`)
}

export async function activateSupportAgreement(id: string) {
  const response = await httpClient.patch<SupportAgreement>(
    `/api/v1/support-agreements/${id}/activate`,
  )

  return response.data
}

export async function getSupportAgreementSuggestions({
  beneficiaryId,
  referenceDate,
}: GetSupportAgreementSuggestionsParams) {
  const params: Record<string, string> = { beneficiaryId }

  if (referenceDate) {
    params.referenceDate = referenceDate
  }

  const response = await httpClient.get<SupportAgreement[]>(
    "/api/v1/support-agreements/suggestions",
    { params },
  )

  return response.data
}

export async function createSupportAgreementVersion({
  id,
  data,
}: {
  id: string
  data: CreateSupportAgreementVersionRequest
}) {
  const response = await httpClient.post<SupportAgreement>(
    `/api/v1/support-agreements/${id}/versions`,
    data,
  )

  return response.data
}