import { zodResolver } from "@hookform/resolvers/zod"
import { Controller, useForm, useWatch } from "react-hook-form"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

import {
    financialTransactionFormSchema,
    type FinancialTransactionFormData,
    type FinancialTransactionFormInput,
} from "@/features/financial-transactions/financial-transaction-schema"
import { financialTransactionTypeLabels } from "@/features/financial-transactions/financial-transaction-labels"

import { useEffect } from "react"
import { useAccountOptions } from "@/features/accounts/hooks/use-account-options"
import { CurrencyInput } from "@/components/form/currency-input"
import { CategoryComboboxWithCreate } from "@/features/categories/components/category-combobox-with-create"
import { AccountComboboxWithCreate } from "@/features/accounts/components/account-combobox-with-create"
import { FiscalDocumentPolicyField } from "./fiscal-document-policy-field"
import type { AttachmentType } from "@/features/attachments/attachment-types"
import type {
    CreateTransactionAllocationRequest,
    TransferDirection,
} from "../financial-transaction-types"
import { useAccounts } from "@/features/accounts/hooks/use-accounts"

type FinancialTransactionFormProps = {
    onSubmit: (
        submission: CreateManualTransactionSubmission,
    ) => void
    isSubmitting?: boolean
    defaultValues?: Partial<FinancialTransactionFormInput>
    submitLabel?: string
    disableAccountField?: boolean
    showFiscalDocumentPolicy?: boolean
}

type AllocationFormItem = {
    fundId: string;
    beneficiaryId: string;
    referenceMonth: string;
    amount: string;
};

export type PendingManualAttachment = {
    id: string
    type: AttachmentType
    file: File | null
}

export type CreateManualTransactionSubmission = {
    data: FinancialTransactionFormData
    allocations: CreateTransactionAllocationRequest[]
    attachments: {
        type: AttachmentType
        file: File
    }[]
    transferDirection: TransferDirection | null
    transferCounterpartyAccountId: string | null
    matchingTransactionId: string | null
}

export function CreateManualTransactionForm({
    onSubmit,
    isSubmitting = false,
    defaultValues,
    submitLabel = "Salvar transação",
    disableAccountField,
    showFiscalDocumentPolicy = true,
}: FinancialTransactionFormProps) {
    const {
        register,
        handleSubmit,
        setValue,
        reset,
        control,
        formState: { errors },
    } = useForm<
        FinancialTransactionFormInput,
        unknown,
        FinancialTransactionFormData
    >({
        resolver: zodResolver(financialTransactionFormSchema),
        defaultValues: {
            accountId: defaultValues?.accountId ?? "",
            type: defaultValues?.type ?? "EXPENSE",
            categoryId: defaultValues?.categoryId ?? "",
            dueDate:
                defaultValues?.dueDate ?? new Date().toISOString().slice(0, 10),
            settlementDate: defaultValues?.settlementDate ?? "",
            expectedAmount: defaultValues?.expectedAmount ?? 0,
            settledAmount: defaultValues?.settledAmount ?? undefined,
            description: defaultValues?.description ?? "",
            documentNumber: defaultValues?.documentNumber ?? "",
            fiscalDocumentPolicy: defaultValues?.fiscalDocumentPolicy ?? "CATEGORY",
            fiscalDocumentNote: defaultValues?.fiscalDocumentNote ?? "",
        },
    })

    useEffect(() => {
        if (!defaultValues) {
            return
        }

        reset({
            accountId: defaultValues.accountId ?? "",
            type: defaultValues.type ?? "EXPENSE",
            categoryId: defaultValues.categoryId ?? "",
            dueDate: defaultValues.dueDate ?? "",
            settlementDate: defaultValues.settlementDate ?? "",
            expectedAmount: defaultValues.expectedAmount ?? 0,
            settledAmount: defaultValues.settledAmount ?? undefined,
            description: defaultValues.description ?? "",
            documentNumber: defaultValues.documentNumber ?? "",
            fiscalDocumentPolicy: defaultValues.fiscalDocumentPolicy ?? "CATEGORY",
            fiscalDocumentNote: defaultValues.fiscalDocumentNote ?? "",
        })
    }, [defaultValues, reset])

    const selectedType = useWatch({ control, name: "type" })
    const selectedAccountId = useWatch({ control, name: "accountId" })
    const selectedCategoryId = useWatch({ control, name: "categoryId" })

    const fiscalDocumentPolicy = useWatch({
        control,
        name: "fiscalDocumentPolicy",
    })

    const fiscalDocumentNote = useWatch({
        control,
        name: "fiscalDocumentNote",
    })

    const accountsQuery = useAccountOptions()

    const [transferDirection, setTransferDirection] =
        useState<TransferDirection>("OUT")

    const [
        transferCounterpartyAccountId,
        setTransferCounterpartyAccountId,
    ] = useState("")

    const [
        matchingTransactionId,
        setMatchingTransactionId,
    ] = useState("")

    const [allocations, setAllocations] =
        useState<AllocationFormItem[]>([])

    const [pendingAttachments, setPendingAttachments] =
        useState<PendingManualAttachment[]>([])

    const selectedSettlementDate =
        useWatch({
            control,
            name: "settlementDate",
        })

    const selectedExpectedAmount =
        useWatch({
            control,
            name: "expectedAmount",
        })

    const transferMatchQuery =
        useDraftTransferMatchSuggestion(
            {
                accountId: selectedAccountId,
                direction: transferDirection,
                transferDate:
                    selectedSettlementDate ?? "",
                amount:
                    Number(selectedExpectedAmount ?? 0),
            },
            {
                enabled:
                    selectedType === "TRANSFER" &&
                    Boolean(selectedAccountId) &&
                    Boolean(selectedSettlementDate) &&
                    Number(selectedExpectedAmount ?? 0) > 0,
            },
        )

    const transferCandidates =
        transferMatchQuery.data?.candidates ?? []

    const accountsQuery =
        useAccounts({
            page: 0,
            size: 200,
        })

    const transferCounterpartyAccountOptions =
        accountsQuery.data?.content

            .filter(
                (account) =>
                    account.active &&
                    account.type !== "CREDIT_CARD" &&
                    account.id !== selectedAccountId,
            )

            .map((account) => ({
                value: account.id,

                label: account.bankName
                    ? `${account.name} · ${account.bankName}`
                    : account.name,
            })) ?? []

    const validAllocations =
        selectedType === "TRANSFER"
            ? []
            : allocations

                .filter(
                    (allocation) =>
                        allocation.fundId &&
                        Number(allocation.amount) > 0,
                )

                .map((allocation) => ({
                    fundId: allocation.fundId,

                    beneficiaryId:
                        allocation.beneficiaryId || null,

                    amount:
                        Math.abs(
                            Number(allocation.amount),
                        ),

                    referenceMonth:
                        allocation.referenceMonth
                            ? `${allocation.referenceMonth}-01`
                            : null,
                }))

    useEffect(() => {
        if (transferCandidates.length !== 1) {
            return
        }

        const candidate =
            transferCandidates[0]

        setMatchingTransactionId(
            candidate.transactionId,
        )

        setTransferCounterpartyAccountId(
            candidate.account.id,
        )
    }, [transferCandidates])

    useEffect(() => {
        setMatchingTransactionId("")
    }, [
        selectedAccountId,
        transferDirection,
        selectedSettlementDate,
        selectedExpectedAmount,
    ])

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                    <Label>Conta</Label>
                    <AccountComboboxWithCreate
                        value={selectedAccountId}
                        disabled={disableAccountField}
                        allowClear={false}
                        onChange={(value) =>
                            setValue("accountId", value, {
                                shouldValidate: true,
                            })
                        }
                    />

                    {errors.accountId && (
                        <p className="text-sm text-destructive">
                            {errors.accountId.message}
                        </p>
                    )}
                </div>

                <div className="space-y-2">
                    <Label>Tipo</Label>
                    <Select
                        value={selectedType}
                        onValueChange={(value) => {
                            const nextType = value as FinancialTransactionFormInput["type"]

                            setValue("type", nextType, {
                                shouldValidate: true,
                            })

                            setValue("categoryId", "", {
                                shouldValidate: true,
                            })

                            if (nextType !== "EXPENSE") {
                                setValue("fiscalDocumentPolicy", "CATEGORY", {
                                    shouldValidate: true,
                                })

                                setValue("fiscalDocumentNote", "", {
                                    shouldValidate: true,
                                })
                            }
                        }}
                    >
                        <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>

                        <SelectContent>
                            {Object.entries(financialTransactionTypeLabels).map(
                                ([value, label]) => (
                                    <SelectItem key={value} value={value}>
                                        {label}
                                    </SelectItem>
                                ),
                            )}
                        </SelectContent>
                    </Select>

                    {errors.type && (
                        <p className="text-sm text-destructive">{errors.type.message}</p>
                    )}
                </div>
            </div>

            {selectedType !== "TRANSFER" && (
                <div className="space-y-2">
                    <Label>Categoria</Label>
                    <CategoryComboboxWithCreate
                        value={selectedCategoryId ?? ""}
                        type={selectedType}
                        placeholder="Selecione a categoria"
                        searchPlaceholder="Buscar categoria..."
                        emptyMessage="Nenhuma categoria encontrada."
                        allowClear={false}
                        disabled={false}
                        onChange={(value) => {
                            setValue("categoryId", value, {
                                shouldValidate: true,
                            })
                        }}
                    />

                    {errors.categoryId && (
                        <p className="text-sm text-destructive">
                            {errors.categoryId.message}
                        </p>
                    )}
                </div>
            )}

            {selectedType === "TRANSFER" &&
                transferCandidates.length > 0 && (
                    <div className="space-y-3 rounded-lg border border-blue-200 bg-blue-50 p-4">
                        <div>
                            <p className="font-medium text-blue-950">
                                Possível movimentação correspondente
                            </p>

                            <p className="text-sm text-blue-800">
                                Já existe uma movimentação de mesmo valor
                                em outra conta. Ao selecioná-la, o sistema
                                criará somente a ponta que está faltando.
                            </p>
                        </div>

                        <EntityCombobox
                            value={matchingTransactionId}
                            options={transferCandidates.map(
                                (candidate) => ({
                                    value: candidate.transactionId,

                                    label:
                                        `${candidate.account.name} · ` +
                                        `${formatCurrency(candidate.amount)} · ` +
                                        `${candidate.settlementDate} · ` +
                                        candidate.description,
                                }),
                            )}
                            placeholder="Selecione a movimentação existente"
                            searchPlaceholder="Buscar movimentação..."
                            emptyMessage="Nenhuma candidata encontrada."
                            allowClear
                            onChange={(value) => {
                                setMatchingTransactionId(value)

                                const candidate =
                                    transferCandidates.find(
                                        (item) =>
                                            item.transactionId === value,
                                    )

                                if (candidate) {
                                    setTransferCounterpartyAccountId(
                                        candidate.account.id,
                                    )
                                }
                            }}
                        />
                    </div>
                )}

            {showFiscalDocumentPolicy && selectedType === "EXPENSE" && (
                <FiscalDocumentPolicyField
                    value={fiscalDocumentPolicy ?? "CATEGORY"}
                    note={fiscalDocumentNote ?? ""}
                    policyError={errors.fiscalDocumentPolicy?.message}
                    noteError={errors.fiscalDocumentNote?.message}
                    onValueChange={(value) => {
                        setValue("fiscalDocumentPolicy", value, {
                            shouldValidate: true,
                        })

                        if (value === "CATEGORY" || value === "REQUIRED") {
                            setValue("fiscalDocumentNote", "", {
                                shouldValidate: true,
                            })
                        }
                    }}
                    onNoteChange={(value) =>
                        setValue("fiscalDocumentNote", value, {
                            shouldValidate: true,
                        })
                    }
                />
            )}

            <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                    <Label htmlFor="dueDate">Data de vencimento</Label>
                    <Input id="dueDate" type="date" {...register("dueDate")} />
                    {errors.dueDate && (
                        <p className="text-sm text-destructive">
                            {errors.dueDate.message}
                        </p>
                    )}
                </div>

                <div className="space-y-2">
                    <Label htmlFor="settlementDate">Data de baixa</Label>
                    <Input
                        id="settlementDate"
                        type="date"
                        {...register("settlementDate")}
                    />
                    {errors.settlementDate && (
                        <p className="text-sm text-destructive">
                            {errors.settlementDate.message}
                        </p>
                    )}
                </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                    <Label htmlFor="expectedAmount">Valor previsto</Label>
                    <Controller
                        name="expectedAmount"
                        control={control}
                        render={({ field }) => (
                            <CurrencyInput
                                id="expectedAmount"
                                value={field.value as number | null | undefined}
                                onValueChange={field.onChange}
                            />
                        )}
                    />
                    {errors.expectedAmount && (
                        <p className="text-sm text-destructive">
                            {errors.expectedAmount.message}
                        </p>
                    )}
                </div>

                <div className="space-y-2">
                    <Label htmlFor="settledAmount">Valor baixado</Label>
                    <Controller
                        name="settledAmount"
                        control={control}
                        render={({ field }) => (
                            <CurrencyInput
                                id="settledAmount"
                                value={field.value as number | null | undefined}
                                allowEmpty
                                onValueChange={field.onChange}
                            />
                        )}
                    />
                    {errors.settledAmount && (
                        <p className="text-sm text-destructive">
                            {errors.settledAmount.message}
                        </p>
                    )}
                </div>
            </div>

            <div className="space-y-2">
                <Label htmlFor="description">Descrição interna</Label>
                <Textarea
                    id="description"
                    placeholder="Descrição opcional para uso interno..."
                    {...register("description")}
                />
                {errors.description && (
                    <p className="text-sm text-destructive">
                        {errors.description.message}
                    </p>
                )}
            </div>

            <div className="space-y-2">
                <Label htmlFor="documentNumber">Número do documento</Label>
                <Input
                    id="documentNumber"
                    placeholder="Ex: NF-123, REC-456, DOC-789"
                    {...register("documentNumber")}
                />
                {errors.documentNumber && (
                    <p className="text-sm text-destructive">
                        {errors.documentNumber.message}
                    </p>
                )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
                <Button
                    type="submit"
                    disabled={isSubmitting || accountsQuery.isLoading}
                >
                    {isSubmitting ? "Salvando..." : submitLabel}
                </Button>
            </div>
        </form>
    )
}